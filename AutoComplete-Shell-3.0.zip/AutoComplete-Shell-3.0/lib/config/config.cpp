#include "config.hpp"

CONFIGURABLE_SETTING GLB_CONF{" "};
