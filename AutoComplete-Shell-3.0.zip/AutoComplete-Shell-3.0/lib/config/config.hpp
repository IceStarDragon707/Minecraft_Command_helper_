#ifndef ACShell_CONFIG_CONFIG_HPP
#define ACShell_CONFIG_CONFIG_HPP

#include<iostream>

struct CONFIGURABLE_SETTING
{
	std::string DELIM;
};

extern CONFIGURABLE_SETTING GLB_CONF;

#endif
