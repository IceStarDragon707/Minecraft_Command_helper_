# AutoComplete-Shell
A simple shell with auto completion.  
Only supported in Windows (linux already has [Programmable Completion](http://www.gnu.org/software/bash/manual/bash.html#Programmable-Completion)).

Simply calling `runShell(suggestion[])` (in `acshell.hpp`) will run the shell, returning the input as `std::string`.

## License
This Project is licensed under the terms of MIT License.
